package com.example.geofire

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
